#bedLen= 10
#bedDepth = 2

bedLen= 30
bedDepth = 1.5

flowerDimX=flowerDimY= .5

flowerRows = bedLen/flowerDimX
flowerColumns = bedDepth/flowerDimY

flowersTotal = flowerRows * flowerColumns

print ("Rows: ",flowerRows,"\nColumns: ",flowerColumns,"\nTotal number of Flowers: ",flowersTotal)







