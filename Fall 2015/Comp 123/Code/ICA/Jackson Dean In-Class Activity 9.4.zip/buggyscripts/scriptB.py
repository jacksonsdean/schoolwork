# scriptB.py

x = 3
y = 4
z = 10
print(x, y, z)