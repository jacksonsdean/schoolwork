import turtle

scrn = turtle.Screen()
dale = turtle.Turtle()

scrn.bgcolor("lavender")
dale.color("blue")
dale.begin_fill()
dale.forward(150)
dale.left(120)
dale.forward(150)
dale.left(120)
dale.forward(150)
dale.end_fill()



scrn.exitonclick()