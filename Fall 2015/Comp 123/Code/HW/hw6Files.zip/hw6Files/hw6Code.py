""" =======================================================================
File: hw6Code.py
Author: Your name here

Contains solutions and test calls for Homework 6.
===========================================================================
"""


# =============================
# Import section

from imageTools import *



# =============================
# Function definition section


# -------------------------------------------------------------------------
# Question 1

def squash3(pic):
    """Takes in a picture and makes a new picture whose height
    is 1/3 of the original, but whose width is the same as the original.
    It then creates a squashed version of the original picture by scaling
    down only in the y direction. It returns the new picture."""
    wid = getWidth(pic)
    hgt = getHeight(pic)
    newW = wid
    newH = hgt / 3
    newPic = makePicture(newH, newW)
    for x in range(newW):
        for y in range(newH):
            newPix = getPixel(pic, x, y)
            oldPix = getPixel(pic, x, 3*y)
            setColor(newPic, getColor(oldPix))
    return newPic



    
# -------------------------------------------------------------------------
# Question 2

# Put your definition of freeRotate here





# use test calls in the section at the bottom of the file, or add your own THERE


def computeOldXY(angle, rotX, rotY, newX, newY):
    """Takes in an angle of rotation, the (x, y) for the center of
    rotation, and the (x, y) for the location in the new, rotated image,
    and it computes and returns the (x, y) location in the original image."""
    diffX = newX - rotX
    diffY = newY - rotY
    cosOfAng = math.cos(math.radians(-angle))
    sinOfAng = math.sin(math.radians(-angle))
    oldX = (cosOfAng * diffX) - (sinOfAng * diffY) + rotX
    oldY = (sinOfAng * diffX) + (cosOfAng * diffY) + rotY
    oldX = int(round(oldX))  # convert the (x, y) into integers
    oldY = int(round(oldY))
    return (oldX, oldY)





# -------------------------------------------------------------------------
# Question 3
    
# Put your definition of varyBlend here



# use test calls in the section at the bottom of the file, or add your own THERE
    


# -------------------------------------------------------------------------
# Question 4

# Put your definition of floodFill here



# use test calls in the section at the bottom of the file, or add your own THERE
    


    

# =============================
# Script/test call section


# change the path to the files below to make them work for you, I assumed you
# would temporarily make MediaSources a subfolder of the working folder.

if __name__ == '__main__':
    pic1 = makePicture("MediaSources/fish.jpg")
    pic2 = makePicture("MediaSources/passionflower.jpg")
    pic3 = makePicture("MediaSources/blackcat.jpg")
    pic4 = makePicture("MediaSources/greekruins.jpg")
    
    
    ## Call to squash3
    #sq1 = squash3(pic3)
    #show(sq1)
    #sq2 = squash3(pic1)
    #show(sq2)
    
    
    ## Calls to freeRotate
    #rot1 = freeRotate(pic4, 75, 100, 100)
    #show(rot1)
    #rot2 = freeRotate(pic2, -190, 250, 250)
    #show(rot2)
    
    ## Calls to varyBlend
    #vb1 = varyBlend(pic1, pic3)
    #show(vb1)
    #vb2 = varyBlend(pic4, pic2)
    #show(vb2)
    
    ## Tests for floodFill
    #ff1 = floodFill(pic4, 10, 10, green)
    #show(ff1)
    #ff2 = floodFill(pic1, 10, 10, green)
    #show(ff2)
    
    
