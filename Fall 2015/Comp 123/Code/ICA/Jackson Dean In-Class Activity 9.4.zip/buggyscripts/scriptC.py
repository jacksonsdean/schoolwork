# This program converts celsius to fahrenheit

celsTemp = 30
fraction = 9/5
fahrTemp = (celsTemp * fraction) + 32
print(fahrTemp)
