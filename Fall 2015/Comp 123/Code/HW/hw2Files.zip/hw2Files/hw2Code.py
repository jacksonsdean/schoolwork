# ====================================================================
#
#  Homework 2 solutions
#  <put your name here>
# ====================================================================


# --- NOTE FROM SUSAN ABOUT LAYOUT OF FILE:
# --- Notice how I organized this file. This is a good organization
# --- for your homework files.
# --- * First, all import statements at the top
# --- * Next the function definitions for the questions, in order
# --- * At the bottom of the file, a script section. I am using the
# ---   strange-looking if statement. Any statements inside that if
# ---   statement are performed when you run your file. But they are
# ---   not performed when your file is imported into my testing
# ---   file, which is nice. Feel free to make changes, additions
# ---   or to comment out parts of the script section.


import math
import turtle

# --------------------------------------------------------------------
# Question 1


def proc1(x):
    print(3 * x)
    

def proc2(x):
    return 3 * x



# put your answer to question 1 here



# --------------------------------------------------------------------
# Question 2

# put your answer to question 2 here



# --------------------------------------------------------------------
# Question 3

# put your definition of starOutline here Include a descriptive comment as a
# triple-quoted string right after the def line






# Functions that use starOutline to draw more interesting pictures:

def gridOfStars():
    """Takes in no inputs, and displays a turtle graphics screen. The turtle
    in it draws 9 star shapes in a grid"""
    scr = turtle.Screen()
    ted = turtle.Turtle()
    ted.speed(0)
    for coord in [(0, 0), (-200, 0), (-200, -200), 
                  (0, -200), (200, -200), (200, 0), 
                  (200, 200), (0, 200), (-200, 200)]:
        ted.up()
        ted.goto(coord)
        ted.down()
        starOutline(ted, 60)
    scr.exitonclick()



def spiralOfStars(angle):
    """Takes in one input, an angle, and displays a turtle graphics screen. It then
    draws a series of star shapes, each one rotated by the input angle,
    and a bit bigger than the previous."""
    scr = turtle.Screen()
    tad = turtle.Turtle()
    tad.speed(0)
    for size in range(20, 200, 10):
        starOutline(tad, size)
        tad.left(angle)
    scr.exitonclick()




# --------------------------------------------------------------------
# Question 4

# Uncomment this when you are ready to work on it

#def drawStairs(turt, numSteps, stepSize):
    #"""Takes in three inputs: a turtle, the number of steps in the staircase,
    #and the size of each step (same vertical and horizontal). It draws a
    #staircase with the given number of steps. The bottom step starts where
    #the turtle is, with the steps parallel to the turtle's current heading.
    #Steps are a fixed height and width, and the steps are colored and filled
    #in with the turtle's current color."""
    
    #turt.begin_fill()
    #for i in range(numSteps):
        #turt.left(90)
        #turt.forward(stepsize)
       #turt.right(90)
        #turt.forward(stepSize)
    #turt.right(90)
    #turt.forward( numSteps + stepSize )
    #turt.right(90)
    #turt.forward( numSteps * stepSize )
    #turt.right(180)
    #turt.end_fill()







# --------------------------------------------------------------------
# Script with calls to functions


if __name__ == '__main__':
    # Calls for question 1+2
    r1 = proc1(5)
    r2 = proc2(5)
    print(r1, r2)    
    
    # Calls for question 3
    neighb = turtle.Screen()
    neighb.bgcolor('lavender')
    larissa = turtle.turtle()
    starOutline(larissa, 150)
    neighb.exitonclick()
    gridOfStars()
    spiralOfStars(5)
    
    # Calls for question 4
    # shadedStars()

