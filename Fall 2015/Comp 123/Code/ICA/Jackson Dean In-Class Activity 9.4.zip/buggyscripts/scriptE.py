# scriptE.py

string = "apples"
print(string, string, string)
