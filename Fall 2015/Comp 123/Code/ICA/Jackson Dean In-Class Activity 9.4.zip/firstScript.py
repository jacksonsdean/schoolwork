tripDist = 420
bikePerDay = 50
tripDays = tripDist / bikePerDay
print("To bike", tripDist, "miles, ", bikePerDay, "miles per day, ", "\nit takes", tripDays, "days.")
